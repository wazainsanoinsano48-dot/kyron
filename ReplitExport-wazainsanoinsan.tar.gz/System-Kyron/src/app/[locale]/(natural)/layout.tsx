
'use client';

import { AppHeader } from "@/components/app-header";
import { ChatDialog } from "@/components/chat-dialog";
import { motion } from "framer-motion";
import { naturalNavGroups } from "@/components/app-sidebar-nav-items";

/**
 * @fileOverview Layout del Portal Natural (Ciudadano).
 * Proporciona un entorno UHD refinado para la gestión de identidad personal.
 */

export default function NaturalLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
    const user = { 
        name: "Carlos Mattar", 
        email: "carlos@kyron.com", 
        fallback: "CM",
        color: "bg-primary shadow-glow"
    };

    return (
      <div className="flex min-h-screen bg-background text-foreground relative overflow-x-hidden">
          {/* Fondo HUD Ciudadano - Menos agresivo, más elegante */}
          <div className="fixed inset-0 pointer-events-none -z-10">
            <div className="absolute inset-0 opacity-[0.02] hud-grid" />
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-[800px] bg-primary/[0.03] rounded-full blur-[250px]" />
            <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-[0.01] mix-blend-overlay" />
          </div>

          <div className="flex-1 flex flex-col min-h-screen relative w-full">
              <AppHeader 
                user={user} 
                dashboardHref="/dashboard" 
                navGroups={naturalNavGroups}
              />
              
              <motion.main 
                className="flex-1 w-full p-4 md:p-10 pt-24 md:pt-32 relative z-10"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
              >
                  <div className="max-w-7xl mx-auto w-full">
                    {children}
                  </div>
              </motion.main>
              
              <footer className="p-8 md:p-12 border-t border-white/5 bg-card/40 text-center backdrop-blur-3xl mt-20 relative z-20">
                <p className="text-[10px] font-black uppercase tracking-[1.2em] text-foreground/10 italic">
                  System Kyron v2.6.5 • Nodo Personal • 2026
                </p>
              </footer>
          </div>
          <ChatDialog />
      </div>
    );
}
